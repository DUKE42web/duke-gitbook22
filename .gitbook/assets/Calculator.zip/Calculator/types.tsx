interface StepperProps {
  prompt: string;
  defaultVal: string;
  min?: string;
  max?: string;
  containerClasses?: string;
  setVal?: any;
  isInDollars?: boolean;
  step?: number;
}

interface SliderProps {
  prompt: string;
  defaultVal?: string;
  label: string;
  min?: string;
  max?: string;
  step?: string;
  containerClasses?: string;
  setVal?: any;
}

interface InputProps {
  prompt: string;
  defaultVal: string;
  label: string;
  isInDollars: boolean;
  containerClasses?: string;
  setVal?: any;
}

interface YearlyOutputProps {
  headline?: string;
  dailySavings: number;
  monthlyText?: string;
  dailyText?: string;
  description?: string;
}

export type { StepperProps, SliderProps, InputProps, YearlyOutputProps };
