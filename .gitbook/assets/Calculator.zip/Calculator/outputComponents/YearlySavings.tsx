import { YearlyOutputProps } from '../types';

const avgDaysInMonth = 30.437;
const avgDaysInYear = 365.25;

const formatMoney = (money: number) => {
  const roundedNum = Math.round(money * 100) / 100;
  const arr = roundedNum.toLocaleString().split('.');
  const cents = `${arr[1] || ''}00`.slice(0, 2);
  const dollars = arr[0];
  return {
    dollars,
    cents,
    full: `$${dollars}.${cents}`,
  };
};

const YearlySavings = ({
  dailySavings = 0,
  headline = 'Total Yearly Savings',
  monthlyText = 'Monthly Savings',
  dailyText = 'Daily Savings',
  description,
}: YearlyOutputProps) => {
  const annual = formatMoney(dailySavings * avgDaysInYear);
  const monthly = formatMoney(dailySavings * avgDaysInMonth);
  const daily = formatMoney(dailySavings);

  return (
    <div>
      <h4 className="text-blue text-xl-fixed">{headline}</h4>
      {/* need to adjust line height to vertically top align */}
      <p className="text-blue my-12 text-2xl-fixed align-top" style={{ lineHeight: '55px' }}>
        $<span className="text-3xl-fixed align-top leading-none">{annual.dollars}</span>
        {`.${annual.cents}`}
      </p>
      <div className="flex flex-row justify-center">
        <div className="border-r px-32 border-gray">
          <p className="text-blue align-top text-lg-fixed" style={{ lineHeight: '25px' }}>
            $<span className="text-xl-fixed align-top">{daily.dollars}</span>
            {`.${daily.cents}`}
          </p>
          <p className="text-gray-dark text-xs">{dailyText}</p>
        </div>
        <div className="px-32">
          <p className="text-blue align-top text-lg-fixed" style={{ lineHeight: '25px' }}>
            $<span className="text-xl-fixed align-top">{monthly.dollars}</span>
            {`.${monthly.cents}`}
          </p>
          <p className="text-gray-dark text-xs">{monthlyText}</p>
        </div>
      </div>
      {description && <p className="mt-32 text-gray-dark text-md">{description}</p>}
    </div>
  );
};

export default YearlySavings;
