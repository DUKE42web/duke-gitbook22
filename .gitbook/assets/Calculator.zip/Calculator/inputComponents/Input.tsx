import React, { useState, useEffect } from 'react';
import { InputProps } from '../types';

const Input = ({
  prompt,
  setVal,
  defaultVal = '',
  label,
  isInDollars,
  containerClasses,
}: InputProps) => {
  const [currentVal, setCurrentVal] = useState<string>(defaultVal);
  const handleInputChange = (e: any) => {
    // remove non-digit+dot characters, then remove additional dots after first
    const val = e.target.value?.replace(/[^0-9\\.]/g, '').replace(/(?<=\..*)\./g, '');
    setCurrentVal(val);
  };

  useEffect(() => {
    if (setVal) {
      setVal(currentVal);
    }
  }, [currentVal]);

  return (
    <div className={`overflow-hidden ${containerClasses}`}>
      <h3 id="inputHeadline" className="text-gray-darker text-lg mb-12">
        {prompt}
      </h3>
      <div className="flex flex-1">
        <div className="border-gray-dark border-b flex min-w-0">
          {isInDollars && (
            <span className="self-end mb-8 text-md-fixed text-blue-dark font-bold leading-none">
              $
            </span>
          )}
          <input
            className="appearance-none self-end text-xl-fixed text-blue-dark overflow-hidden"
            value={currentVal}
            type="text"
            inputMode="numeric"
            pattern="[0-9]*\.?[0-9]*"
            aria-labelledby="inputHeadline intervalValue"
            onChange={handleInputChange}
          />
        </div>
        <p id="intervalValue" className="text-md-fixed font-bold ml-16 flex-grow-1 flex-shrink-0">
          {label}
        </p>
      </div>
    </div>
  );
};

export default Input;
