import React, { useState, useEffect } from 'react';
import { StepperProps } from '../types';

const Stepper = ({
  prompt,
  setVal,
  defaultVal = '0',
  min = '0',
  max,
  step = 1,
  containerClasses,
  isInDollars = false,
}: StepperProps) => {
  const minNum = Number(min);
  const maxNum = max ? Number(max) : null;
  const [currentNum, setCurrentNum] = useState<string | number>(defaultVal);
  const decreaseButtonDisabled = Number(currentNum) < minNum + step;
  const increaseButtonDisabled = maxNum ? Number(currentNum) > maxNum - step : false;
  const isDecimal = step % 1 !== 0;

  const handleInputChange = (e: any) => {
    if (isDecimal) {
      const digitsAndDot = e.target.value?.replace(/[^0-9\\.]/g, '').replace(/(?<=\..*)\./g, '');
      setCurrentNum(digitsAndDot);
    } else {
      const digits = e.target.value?.replace(/\D+/g, '');
      setCurrentNum(digits);
    }
  };

  const changeValue = (stepVal: number) => {
    const newVal = Number(currentNum) + stepVal;
    let fixedVar = 0;
    if (isDecimal) {
      fixedVar = 2;
    }
    setCurrentNum(newVal.toFixed(fixedVar));
  };

  useEffect(() => {
    if (setVal) {
      setVal(currentNum);
    }
  }, [currentNum]);

  return (
    <div className={containerClasses}>
      <h3 id="stepperHeadline" className="text-gray-darker text-lg mb-12">
        {prompt}
      </h3>
      <div className="flex flex-1">
        <div className="border-gray-dark border-b flex min-w-0">
          {isInDollars && (
            <span className="self-end mb-8 text-md-fixed text-blue-dark font-bold">$</span>
          )}
          <input
            className="appearance-none self-end w-full text-xl-fixed text-blue-dark"
            value={currentNum}
            type="text"
            inputMode="numeric"
            pattern="[0-9]*"
            aria-labelledby="stepperHeadline"
            onChange={handleInputChange}
          />
        </div>
        <div className="flex flex-1 items-end" role="group" aria-labelledby="stepperHeadline">
          {/* icons should be 32px */}
          <button
            className={`${
              decreaseButtonDisabled ? 'pointer-events-none bg-gray' : 'bg-teal-darker'
            } rounded-full ml-16 mr-24 icon-30 flex-shrink-0`}
            aria-label="Decrease"
            aria-disabled={decreaseButtonDisabled}
            onClick={() => changeValue(-step)}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 70 70"
              aria-hidden="true"
              focusable="false"
            >
              <title>icon minus</title>
              <rect
                x="17.87"
                y="32.62"
                width="34.25"
                height="4.76"
                rx="1.89"
                ry="1.89"
                fill="#fff"
              />
            </svg>
          </button>
          <button
            className={`${
              increaseButtonDisabled ? 'pointer-events-none bg-gray' : 'bg-teal-darker'
            } rounded-full icon-30 flex-shrink-0`}
            aria-label="Increase"
            aria-disabled={increaseButtonDisabled}
            onClick={() => changeValue(step)}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 70 70"
              aria-hidden="true"
              focusable="false"
            >
              <title>icon plus</title>
              <path
                d="M52.34,32.62h-15v-15a1.89,1.89,0,0,0-1.89-1.89h-1a1.89,1.89,0,0,0-1.89,1.89v15h-15a1.89,1.89,0,0,0-1.89,1.89v1a1.89,1.89,0,0,0,1.89,1.89h15v15a1.89,1.89,0,0,0,1.89,1.89h1a1.89,1.89,0,0,0,1.89-1.89v-15h15a1.89,1.89,0,0,0,1.89-1.89v-1A1.89,1.89,0,0,0,52.34,32.62Z"
                fill="#fff"
              />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Stepper;
