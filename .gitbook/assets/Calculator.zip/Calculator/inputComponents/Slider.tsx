import React, { useEffect, useState } from 'react';
import { SliderProps } from '../types';
import './Slider.css';

const Slider = ({
  prompt,
  defaultVal,
  label,
  min = '0',
  max = '100',
  step = '1',
  containerClasses = '',
  setVal,
}: SliderProps) => {
  let defaultNum;
  if (defaultVal || defaultVal === '0') {
    defaultNum = Number(defaultVal);
  } else {
    defaultNum = (Number(max) - Number(min)) / 2 + Number(min);
  }
  const [currentNum, setCurrentNum] = useState(defaultNum);
  // const percentage = (currentNum / Number(max)) * 100;

  useEffect(() => {
    if (setVal) {
      setVal(currentNum);
    }
  }, [currentNum]);

  return (
    <div className={`${containerClasses}`}>
      <h3 id="sliderHeadline" className="text-gray-darker text-lg mb-12">
        {prompt}
      </h3>
      <div className="flex flex-1 mb-24">
        <div className="mr-16 border-gray border-r pr-16">
          <input
            className="appearance-none border-b text-2xl-fixed w-122 text-blue-dark overflow-hidden"
            value={currentNum}
            type="text"
            inputMode="numeric"
            pattern="[0-9]*"
            aria-labelledby="sliderHeadline sliderTitle"
            onChange={e => setCurrentNum(Number(e.target.value))}
          />
        </div>
        <p id="sliderTitle" className="self-center text-lg-fixed font-bold text-gray-darker">
          {label}
        </p>
      </div>
      {/* <div className="relative"> */}
      <input
        className="w-full h-10 appearance-none bg-gray cursor-pointer border border-gray rounded-full"
        type="range"
        min={min}
        max={max}
        id="slider"
        step={step}
        value={currentNum}
        aria-labelledby="sliderHeadline sliderTitle"
        onChange={e => setCurrentNum(Number(e.target.value))}
      />
      {/* <div
          className="absolute h-10 bg-teal-darker rounded-full z-0"
          style={{ width: `${percentage}%`, top: '7px' }}
        />
      </div> */}
    </div>
  );
};

export default Slider;
