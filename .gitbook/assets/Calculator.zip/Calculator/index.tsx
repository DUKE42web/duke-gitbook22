import React from 'react';
import Input from './inputComponents/Input';
import Stepper from './inputComponents/Stepper';
import Slider from './inputComponents/Slider';

const Calculator = () => (
  <section className="px-16 md:px-24 py-32 md:py-48">
    <div className="mb-48 items-center flex">
      <Slider
        prompt="Prompt goes here"
        defaultVal="88888"
        min="0"
        max="100000"
        label="Number Slider Title"
      />
    </div>
    <div className="flex flex-1">
      <Stepper prompt="Prompt goes here" defaultVal="1" />
      <Input prompt="Prompt goes here" defaultVal="500" label="per month" isInDollars={true} />
    </div>
  </section>
);

export default Calculator;
