import React, { useState } from 'react';
import CallToAction from '../CallToAction';
import { EVCalculatorProps } from './types';
import Slider from '../Calculator/inputComponents/Slider';
import Stepper from '../Calculator/inputComponents/Stepper';
import YearlySavings from '../Calculator/outputComponents/YearlySavings';

const EVCalculator = ({ inputs, output, ...rest }: EVCalculatorProps) => {
  const { miles, mpg, gas } = inputs;
  const [sliderVal, setSliderVal] = useState(miles.defaultVal);
  const [mpgVal, setMpgVal] = useState(mpg.defaultVal);
  const [gasVal, setGasVal] = useState(gas.defaultVal);

  const mpgNum = Number(mpgVal || 0);
  const milesNum = Number(sliderVal || 0);
  const residentialRate = 0.1117;
  const avgEVEfficiency = 3.5;
  let gasNum = 0;
  if (gasVal && gasVal !== '.') {
    gasNum = Number(gasVal);
  }
  let dailySavings = 0;
  if (mpgNum !== 0) {
    dailySavings = (milesNum / mpgNum) * gasNum - (milesNum / avgEVEfficiency) * residentialRate;
  }
  return (
    <CallToAction {...rest}>
      <div className="flex flex-1 flex-col md:flex-row pt-12 sm:px-32 container-xs md:container-4xl items-center">
        <div className="w-full md:w-5/12 pb-32 mb-32 md:pb-0 md:mb-0 md:pr-48 flex-shrink-0 border-gray-light border-b md:border-b-0 md:border-r">
          <Slider setVal={setSliderVal} containerClasses="mb-48" {...miles} />
          <div className="flex flex-col xl:flex-row">
            <Stepper
              {...mpg}
              setVal={setMpgVal}
              containerClasses="w-190 xl:w-1/2 mb-32 xl:mr-48 xl:mb-0"
            />
            <Stepper setVal={setGasVal} containerClasses="w-190 xl:w-1/2" {...gas} />
          </div>
        </div>
        <div className="w-full md:w-7/12 md:pl-48 flex-shrink-0 text-center">
          <YearlySavings {...output} dailySavings={dailySavings} />
        </div>
      </div>
    </CallToAction>
  );
};

export default EVCalculator;
