import React from 'react';
import EVCalculator from './index';
import { Data } from './data';
import { compositionFunction } from './composition';

const props = compositionFunction(Data);

export default {
  title: 'Components/EVCalculator',
  component: EVCalculator,
};

const Template = () => {
  return <EVCalculator {...props} />;
};

export const Primary = Template.bind({});
