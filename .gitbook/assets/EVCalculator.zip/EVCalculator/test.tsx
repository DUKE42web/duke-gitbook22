import '@testing-library/jest-dom';
import EVCalculator from './index';
import { fireEvent, Matcher, renderWithCTX, screen } from 'src/lib/testWrappers';
import { compositionFunction } from './composition';
import Data from './data';
jest.mock('src/lib/useIntersection');

const props = compositionFunction(Data);
const { direct, slider } = props.inputs;

describe('EVCalculator', () => {
  it('should render', () => {
    renderWithCTX(<EVCalculator {...props} />);
    const ctaTitle = screen.getByText(props.title!.value as Matcher);
    const annualHeadline = screen.getByRole('heading', { name: props.output.headline });
    const sliderInput = screen.getByRole('slider', { name: `${slider.prompt} ${slider.label}` });
    const outputHeadline = screen.getByRole('heading', { name: props.output.headline });
    expect(ctaTitle).toBeInTheDocument();
    expect(annualHeadline).toBeInTheDocument();
    expect(sliderInput).toBeInTheDocument();
    expect(outputHeadline).toBeInTheDocument();
  });

  it('should show new value in output when input changes', () => {
    const propsCopy = props;
    propsCopy.inputs.direct.defaultVal = '3.25';
    renderWithCTX(<EVCalculator {...propsCopy} />);
    const input = screen.getByRole('textbox', { name: `${direct.prompt} ${direct.label}` });
    const annualHeadline = screen.getByRole('heading', { name: props.output.headline });
    const origYearlyCost = annualHeadline.nextSibling?.textContent;
    fireEvent.change(input, { target: { value: '4.25' } });
    const newYearlyCost = annualHeadline.nextSibling?.textContent;
    expect(newYearlyCost).not.toBe(origYearlyCost);
  });
});
