import Composition from 'src/lib/Composition';
import { compositionFunction as CallToActionComposition } from 'src/components/CallToAction/composition';
import EVCalculator from '.';
import Data from './data';

const { compositionFunction, component } = Composition(EVCalculator)((): any => {
  const CTA = CallToActionComposition(Data);
  return {
    ...CTA,
    inputs: {
      miles: {
        prompt: 'How many miles do you drive daily?',
        defaultVal: '37',
        label: 'Daily miles driven',
        min: 0,
        max: 300,
        step: 1,
      },
      mpg: {
        prompt: 'Miles per gallon',
        defaultVal: '34',
        isInDollars: false,
        step: 1,
      },
      gas: {
        prompt: 'Gas price',
        defaultVal: '3.12',
        isInDollars: true,
        step: 0.1,
      },
    },
    output: {
      headline: 'Total Yearly Savings',
      monthlyText: 'Monthly Savings',
      dailyText: 'Daily Savings',
      description:
        "Significant additional savings can come from a reduction in maintenance costs as EVs do not require oil changes and have far fewer moving parts. How it's calculated.",
    },
  };
});

export { compositionFunction, component as default };
