const Data = {
  fields: {
    // CTA data - calculator data structure unknown
    Icon: {
      value: {
        src: 'https://scdev25.duke-energy.com:443/_/media/images/svg/lights/iconoutdoorlight.svg?h=100&la=en&w=100',
        alt: '',
        width: '76',
        height: '76',
      },
    },
    Headline: {
      value: 'Electric Vehicle Calculator',
    },
    Subhead: {
      value:
        'Use this EV Fuel Savings Estimator to calculate your potential fuel savings from driving an EV.',
    },
    Background: {
      fields: {
        Setting: {
          value: 'White',
        },
        Value: {
          value: 'white-bg',
        },
      },
    },
    BackgroundColor: 'white-bg',
  },
};

export default Data;
