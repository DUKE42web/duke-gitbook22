import { CallToActionProps } from 'src/components/CallToAction/types';
import { StepperProps, SliderProps, YearlyOutputProps } from 'src/components/Calculator/types';

interface InputsType {
  gas: StepperProps;
  mpg: StepperProps;
  miles: SliderProps;
}

interface EVCalculatorProps extends CallToActionProps {
  inputs: InputsType;
  output: YearlyOutputProps;
}

export type { EVCalculatorProps };
